-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2024 at 10:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookbound`
--
CREATE DATABASE IF NOT EXISTS `bookbound` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `bookbound`;

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `AccountID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `PenName` varchar(50) NOT NULL,
  `DP` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`AccountID`, `Name`, `Email`, `Password`, `PenName`, `DP`) VALUES
(1, 'testing', 'testing@gmail.com', 'testing', 'Anonymous', ''),
(2, 'IaxxeI', 'johnhermanrestauro83@gmail.com', 'newpass', 'Anonymous', ''),
(3, 'ryan', 'Ral531715@gmail.com', 'Password', 'Anonymous', ''),
(4, 'kyu', 'micaacec@gmail.com', 'password', 'Anonymous', ''),
(6, 'kya', 'acy995kim@gmail.com', 'password', 'Anonymous', '');

-- --------------------------------------------------------

--
-- Table structure for table `bookbound`
--

CREATE TABLE `bookbound` (
  `LNID` int(11) NOT NULL,
  `TITLE` text NOT NULL,
  `ACCOUNTID` int(11) NOT NULL,
  `STATUS` varchar(100) NOT NULL,
  `SYPNOSIS` longtext NOT NULL,
  `GENRE` varchar(100) NOT NULL,
  `DESCRIPTION` longtext NOT NULL,
  `LNTEXT` longtext NOT NULL,
  `DATE_ADDED` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `synopsis` text NOT NULL,
  `published_date` date DEFAULT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `title`, `author`, `genre`, `description`, `synopsis`, `published_date`, `date_added`) VALUES
(1, 'The Great Adventure', 'John Doe', 'Fantasy', 'A thrilling fantasy novel about an epic quest.', 'An unlikely hero embarks on a dangerous journey to save the world.', '2024-05-01', '2024-11-17 11:53:56'),
(2, 'Mystery of the Lost Artifact', 'Jane Smith', 'Mystery', 'A detective novel set in a small town with a hidden secret.', 'A detective investigates a series of strange occurrences that lead to a long-lost treasure.', '2023-08-15', '2024-11-17 11:53:56');

-- --------------------------------------------------------

--
-- Table structure for table `chapters`
--

CREATE TABLE `chapters` (
  `chapter_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `chapter_title` varchar(255) NOT NULL,
  `chapter_number` varchar(30) NOT NULL,
  `content` longtext NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`chapter_id`, `book_id`, `chapter_title`, `chapter_number`, `content`, `date_added`) VALUES
(1, 1, 'The Beginning of the Journey', '1', 'The adventure begins when the hero receives a mysterious letter...', '2024-11-17 12:07:20'),
(2, 1, 'Into the Dark Forest', '2', '    The forest was a creature of shadows, a silent sentinel guarding secrets older than time. It was a place where sunlight dared not tread, where the air was thick with the scent of decay and the promise of unknown terrors. Yet, it was here that Elara, a young woman of unwavering spirit, found herself compelled to venture.\r\n\r\n    A prophecy, as old as the trees themselves, had foretold of a chosen one, a guardian destined to protect the ancient heart of the forest. Elara, with her emerald eyes and a heart as pure as the mountain streams, was believed to be the one. Armed with a worn leather satchel, a trusty dagger, and a will as sharp as the forest’s thorns, she stepped into the unknown.\r\n\r\n    The deeper she ventured, the more the forest seemed to close in around her. Twisted branches reached out like gnarled fingers, the undergrowth clawed at her legs, and the wind whispered cryptic warnings. Strange, otherworldly sounds echoed through the trees, the cries of unseen creatures that stirred unease in her heart.\r\n\r\n    Her first encounter was with the forest’s guardian, a wise old oak with roots that delved deep into the earth. It spoke to her in a language of rustles and sighs, imparting ancient knowledge and a cryptic riddle. The solution to the riddle, the oak revealed, lay at the heart of the forest, a place of both beauty and danger.\r\n\r\n    Guided by the oak’s wisdom, Elara pressed on. She faced trials that tested her strength, her courage, and her faith. She outwitted cunning tricksters, battled fearsome beasts, and deciphered ancient symbols. Each challenge was a step closer to the heart of the forest, a place where the veil between worlds was thin.\r\n\r\n    As she neared her destination, the forest grew more hostile. The air crackled with dark energy, and the ground trembled beneath her feet. A shadowy figure emerged from the gloom, a creature of pure malice with eyes that burned with an infernal fire. It was the guardian of the forest’s darkest secrets, a being of immense power, corrupted by the very essence it was meant to protect.\r\n\r\n    A fierce battle ensued, a clash of light and darkness. Elara fought with a ferocity born of desperation, her blade flashing in the dim light. The creature’s attacks were relentless, but she met each blow with unwavering determination. With a final, desperate strike, she shattered the creature’s dark heart, banishing it to the void from whence it came.\r\n\r\n    In the aftermath of the battle, a sense of peace settled over the forest. The air grew lighter, the shadows retreated, and the ancient trees seemed to sigh in relief. Elara, weary but triumphant, had fulfilled her destiny. She had ventured into the heart of darkness and emerged victorious, a beacon of hope in a world shrouded in shadow.\r\n\r\n    As she turned to leave, the old oak spoke once more, its voice filled with gratitude. \"You have saved us, child,\" it said. \"May the forest forever remember your name.\" With a final glance at the ancient trees, Elara turned and walked away, carrying the weight of her victory and the knowledge that she had become a guardian of the forest, a protector of the light against the encroaching darkness.', '2024-11-17 12:07:20'),
(3, 2, 'The First Clue', '1', 'The detective finds the first clue hidden in the old library...', '2024-11-17 12:07:21'),
(4, 2, 'A Dark Secret', '2', 'A Dark Turn\n\nDetective Alex Harper was a man accustomed to the grim realities of his job. He’d seen his fair share of twisted crimes, but the case of the missing heiress, Eleanor Van Derlyn, was different. There was something about the elegant woman, her mysterious disappearance, and the hushed whispers that followed, that intrigued him.\n\nThe initial investigation had led to a dead end. The opulent Van Derlyn mansion, a relic of a bygone era, held no clues. The staff, a tight-lipped group of loyal servants, offered little help. The only lead they had was a cryptic note found in Eleanor’s room, a single word scrawled in elegant cursive: “Elysium.”\n\nAs Harper delved deeper into the case, he began to uncover a web of secrets and deceit. The Van Derlyns, once a beacon of society, were shrouded in darkness. Old family feuds, hidden alliances, and a shadowy cult known as the Order of Elysium began to emerge.\n\nA peculiar symbol, a stylized eye surrounded by a serpent, kept appearing in the most unexpected places: on ancient manuscripts, in hidden chambers of the mansion, and even in the cryptic note. It was a symbol of the Order, a secret society that had existed for centuries, rumored to possess immense power and influence.\n\nHarper’s investigation led him to a reclusive scholar, Dr. Evelyn Ashton, an expert on occult history. Dr. Ashton revealed that the Order of Elysium was a dangerous cult, obsessed with ancient rituals and dark magic. She warned Harper that the Order would stop at nothing to protect their secrets, and that Eleanor might be caught in their sinister plans.\n\nFollowing a trail of cryptic clues, Harper found himself in a forgotten part of the city, a dilapidated warehouse on the waterfront. Inside, he discovered a hidden chamber, a place of dark rituals and forbidden knowledge. The walls were adorned with the same symbol of the Order, and the air was thick with the scent of incense and fear.\n\nA confrontation with the Order ensued, a brutal clash between good and evil. Harper, armed with his wits and a revolver, fought against the cultists, their eyes glowing with a sinister light. In the chaos, he managed to rescue Eleanor, who was held captive, a sacrificial lamb for an ancient ritual.\n\nAs the dust settled, the Order was dismantled, and its secrets were exposed to the world. Eleanor, traumatized but alive, was reunited with her family. Harper, though physically scarred, emerged as a hero, a man who had dared to confront the darkness and emerged victorious.\n\nBut the case had taken its toll on him. The secrets he had uncovered had haunted his dreams, and the knowledge of the Order’s power had left him uneasy. He knew that the darkness he had fought was far from defeated, and that it would continue to lurk in the shadows, waiting for its next opportunity to strike.', '2024-11-17 12:07:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`AccountID`);

--
-- Indexes for table `bookbound`
--
ALTER TABLE `bookbound`
  ADD PRIMARY KEY (`LNID`),
  ADD KEY `ACCOUNTID` (`ACCOUNTID`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `chapters`
--
ALTER TABLE `chapters`
  ADD PRIMARY KEY (`chapter_id`),
  ADD KEY `book_id` (`book_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `AccountID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `bookbound`
--
ALTER TABLE `bookbound`
  MODIFY `LNID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `chapters`
--
ALTER TABLE `chapters`
  MODIFY `chapter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookbound`
--
ALTER TABLE `bookbound`
  ADD CONSTRAINT `bookbound_ibfk_1` FOREIGN KEY (`ACCOUNTID`) REFERENCES `accounts` (`AccountID`);

--
-- Constraints for table `chapters`
--
ALTER TABLE `chapters`
  ADD CONSTRAINT `chapters_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
